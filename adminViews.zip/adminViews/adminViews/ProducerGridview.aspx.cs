﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;

namespace adminViews
{
    public partial class ProducerGridview : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Page_PreRender(object sender, EventArgs e)
        {
            if(GridView1.SelectedRow != null)
            {
                GridView2.Visible = true;
                ddlMovieID.Visible = true;
                txtTitle.Visible = true;
                btnAdd.Visible = true;
                lblMovieID.Visible = true;
                lblTitle.Visible = true;
            }
            else
            {
                GridView2.Visible = false;
                ddlMovieID.Visible = false;
                txtTitle.Visible = false;
                btnAdd.Visible = false;
                lblMovieID.Visible = false;
                lblTitle.Visible = false;
            }
        }

       protected void btnIsert_Click(object sender, EventArgs e)
        {
            SqlDataSource1.InsertParameters["producer_fname"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtFName")).Text;
            SqlDataSource1.InsertParameters["producer_lname"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtLName")).Text;

            try
            {
                SqlDataSource1.Insert();
                ((TextBox)GridView1.FooterRow.FindControl("txtFName")).Text = "";
                ((TextBox)GridView1.FooterRow.FindControl("txtLName")).Text = "";
            }
            catch
            {
                Response.Write("<script>alert('An error has occurred with your request.')</script>");
            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            SqlDataSource2.InsertParameters["mov_id"].DefaultValue = ddlMovieID.SelectedValue;
            SqlDataSource2.InsertParameters["prod_id"].DefaultValue = ((Label)GridView1.SelectedRow.FindControl("Label1")).Text;
            SqlDataSource2.InsertParameters["title"].DefaultValue = txtTitle.Text;

            try
            {
                SqlDataSource2.Insert();                
                txtTitle.Text = "";
            }
            catch
            {
                Response.Write("<script>alert('An error has occurred with your request.')</script>");
            }
        }

        protected void GridView1_RowUpdated(object sender, GridViewUpdatedEventArgs e)
        {
            if (e.Exception != null)
            {
                e.ExceptionHandled = true;
                Response.Write("<script>alert('An error has occurred with your update request.')</script>");
            }
            else if (e.AffectedRows == 0)
            {
                Response.Write("<script>alert('Another admin may have updated this producer.')</script>");
            }
        }

        protected void GridView1_RowDeleted(object sender, GridViewDeletedEventArgs e)
        {
            if (e.Exception != null)
            {
                e.ExceptionHandled = true;
                Response.Write("<script>alert('An error has occurred with your delete request.')</script>");
            }
            else if (e.AffectedRows == 0)
            {
                Response.Write("<script>alert('Another admin may have deleted this producer.')</script>");
            }
            else
            {
                Response.Redirect(Request.RawUrl, false);
            }
        }

        protected void GridView2_RowDeleted(object sender, GridViewDeletedEventArgs e)
        {
            if (e.Exception != null)
            {
                e.ExceptionHandled = true;
                Response.Write("<script>alert('An error has occurred with your delete request.')</script>");
            }
            else if (e.AffectedRows == 0)
            {
                Response.Write("<script>alert('Another admin may have deleted this producer title.')</script>");
            }
        }

        protected void GridView2_RowUpdated(object sender, GridViewUpdatedEventArgs e)
        {
            if (e.Exception != null)
            {
                e.ExceptionHandled = true;
                Response.Write("<script>alert('An error has occurred with your update request.')</script>");
            }
            else if (e.AffectedRows == 0)
            {
                Response.Write("<script>alert('Another admin may have updated this producer title.')</script>");
            }
        }
    }
}