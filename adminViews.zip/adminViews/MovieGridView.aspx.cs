﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace adminViews
{
    public partial class MovieGridView : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            SqlDataSource1.InsertParameters["movie_title"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtMovieTitle")).Text;
            SqlDataSource1.InsertParameters["movie_runlength"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtMovieRunLength")).Text;
            SqlDataSource1.InsertParameters["movie_releaseYear"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtMovieReleaseYear")).Text;
            SqlDataSource1.InsertParameters["movie_dir_id"].DefaultValue = ((DropDownList)GridView1.FooterRow.FindControl("ddlDirID")).SelectedValue;
            SqlDataSource1.InsertParameters["movie_rating"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtMovieRating")).Text;

            try
            {
                SqlDataSource1.Insert();
                ((TextBox)GridView1.FooterRow.FindControl("txtMovieTitle")).Text = "";
                ((TextBox)GridView1.FooterRow.FindControl("txtMovieRunLength")).Text = "";
                ((TextBox)GridView1.FooterRow.FindControl("txtMovieReleaseYear")).Text = "";                
                ((TextBox)GridView1.FooterRow.FindControl("txtMovieRating")).Text = "";
            }
            catch
            {
                Response.Write("<script>alert('An error has occurred with your insert request.')</script>");
            }

        }
    }
}