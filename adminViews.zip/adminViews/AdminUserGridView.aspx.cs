﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace adminViews
{
    public partial class AdminUserGridView : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            SqlDataSource1.InsertParameters["user_username"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtUsername")).Text;
            SqlDataSource1.InsertParameters["user_password"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtPassword")).Text;
            SqlDataSource1.InsertParameters["user_fname"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtFName")).Text;
            SqlDataSource1.InsertParameters["user_lname"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtLName")).Text;
            SqlDataSource1.InsertParameters["user_email"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtEmail")).Text;
            SqlDataSource1.InsertParameters["user_DOB"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtDOB")).Text;

            try
            {
                SqlDataSource1.Insert();
                ((TextBox)GridView1.FooterRow.FindControl("txtUsername")).Text = "";
                ((TextBox)GridView1.FooterRow.FindControl("txtPassword")).Text = "";
                ((TextBox)GridView1.FooterRow.FindControl("txtFName")).Text = "";
                ((TextBox)GridView1.FooterRow.FindControl("txtLName")).Text = "";
                ((TextBox)GridView1.FooterRow.FindControl("txtEmail")).Text = "";
                ((TextBox)GridView1.FooterRow.FindControl("txtDOB")).Text = "";
            } 
            catch
            {
                Response.Write("<script>alert('An error has occurred with your insert request.')</script>");
            }
        }

        protected void GridView1_RowDeleted(object sender, GridViewDeletedEventArgs e)
        {
            if (e.Exception != null)
            {
                e.ExceptionHandled = true;
                Response.Write("<script>alert('An error has occurred with your delete request.')</script>");
            }
            else if (e.AffectedRows == 0)
            {
                Response.Write("<script>alert('Another admin may have deleted this user.')</script>");
            }
            else
            {
                Response.Redirect(Request.RawUrl, false);
            }
        }

        protected void GridView1_RowUpdated(object sender, GridViewUpdatedEventArgs e)
        {
            if (e.Exception != null)
            {
                e.ExceptionHandled = true;
                Response.Write("<script>alert('An error has occurred with your update request.')</script>");
            }
            else if (e.AffectedRows == 0)
            {
                Response.Write("<script>alert('Another admin may have updated this user.')</script>");
            }
        }

        protected void GridView2_RowDeleted(object sender, GridViewDeletedEventArgs e)
        {
            if (e.Exception != null)
            {
                e.ExceptionHandled = true;
                Response.Write("<script>alert('An error has occurred with your delete request.')</script>");
            }
            else if (e.AffectedRows == 0)
            {
                Response.Write("<script>alert('Another admin may have deleted this rating.')</script>");
            }
        }        
    }
}