﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HealthyTomatoes
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            /**
             * Check if user has logged in or not.
             */
            string username = (String)Session["Username"];

            if (username == "" || username == null)
            {
                lbl_Link.Text = "Log In";
                hl_login.NavigateUrl = "login.aspx";
            }
            else
            {
                lbl_Link.Text = "Welcome, " + username;
                hl_login.NavigateUrl = "";
            }

            /**
             *  Get information of top rated movie to display on home page.
             */

        }
    }
}